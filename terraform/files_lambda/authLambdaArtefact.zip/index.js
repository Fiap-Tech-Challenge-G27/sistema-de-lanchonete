exports.handler = async function (event, context){

    const res = 'Hello World';

    return res;
}
